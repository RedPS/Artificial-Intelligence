# cs482-fall2018
Project Code For cs482/682 Fall 2018 @ UNR

# project 1

Create a tic-tac-toe move-maker program. I've given you some skeleton file I/O code that you can use and the spec for some functions that you have to fill in. Make those functions work, and you should get an 'A'

## to compile

```
mkdir build && cd build
cmake ..
make
```
